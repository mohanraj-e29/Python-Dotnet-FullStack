import React from 'react'

function Index() {
  return (
    <div className='bg-gray-500 h-[100vh]'>
      <h1 className='text-2xl'>Hii</h1>
    </div>
  )
}

export default Index
